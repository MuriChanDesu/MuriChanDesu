use warnings;
use strict;

open(sortedFile,"<", $ARGV[0]) or die "Cant open file!";   

my @listOfWords=<sortedFile>;

print for map $_->[0],
        sort { $a->[1] cmp $b->[1] }
        map [ $_, join q(), /[aeiou]/g ],
        @listOfWords;
