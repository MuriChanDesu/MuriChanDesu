use strict;
use warnings;
use IO::Socket::INET;

@ARGV == 2 || die "Usage: $0 server port\n";
my ($ip, $port) = @ARGV;

my $socket = IO::Socket::INET->new(
    PeerAddr    => $ip,
    PeerPort     => $port,
    Proto        => "tcp"
);

print "Username: ";
my $user = <STDIN>;
print "Password: ";
my $pass = <STDIN>;

print "MSG TO CLIENT: ";
while (defined($msg = <STDIN>)) {
    if ($msg =~ /^quit/i) {
        last;
    }

print $socket $msg;
}

$socket->close();
